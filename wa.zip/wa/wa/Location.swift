//
//  Location.swift
//  wa
//
//  Created by User on 28.04.2020.
//  Copyright © 2020 User. All rights reserved.
//

import Foundation

class Location {
     static var sharedInstance = Location()
    
    var longitude: Double = 0.0
    var latitude: Double = 0.0
}
