//
//  Extras.swift
//  wa
//
//  Created by User on 24.04.2020.
//  Copyright © 2020 User. All rights reserved.
//

import Foundation

let API_URL = "http://api.openweathermap.org/data/2.5/weather?lat=\(Location.sharedInstance.latitude)&lon=\(Location.sharedInstance.longitude)&appid=fcd8df7d22bcd68b830cafd87671929e"

let FORECAST_API_URL = "http://api.openweathermap.org/data/2.5/forecast/daily?lat=\(Location.sharedInstance.latitude)&lon=\(Location.sharedInstance.longitude)&cnt=8&appid=fcd8df7d22bcd68b830cafd87671929e"

typealias DownloadComplete = () -> ()
